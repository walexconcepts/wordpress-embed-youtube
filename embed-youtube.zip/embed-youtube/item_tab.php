<?php 
if( $detail && !empty($detail) ) { 
$result = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM wc_woocommerce_embed_youtube_videos where fk_i_item_id = %d", $itemID ) );		
		foreach ( $result as $row ) {
		$video = $row->s_id;	
		}
?>

<div align="center">
<h4 style="margin-top: 10px;">Youtube video</h4>
<iframe type="text/html"  width="560" height="315"
src="https://www.youtube.com/embed/<?php echo esc_html($video); ?>?autoplay=0&mute=1" name="youtube embed"
allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>
<?php 
} 
