<?php
$mess = array(

"del" => "Record has been Deleted!",

);

?>