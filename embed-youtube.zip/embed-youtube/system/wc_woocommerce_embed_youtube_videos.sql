CREATE TABLE IF NOT EXISTS wc_woocommerce_embed_youtube_videos (
    fk_i_item_id INT(10) UNSIGNED NOT NULL,
	s_name VARCHAR(100) NULL,
    s_youtube VARCHAR(100) NULL,
    s_id varchar(15) NOT NULL DEFAULT '-no-id-',
    PRIMARY KEY (fk_i_item_id)
) ENGINE=InnoDB DEFAULT CHARACTER SET 'UTF8' COLLATE 'UTF8_GENERAL_CI' ;



