<?php
/*
 Plugin Name: Embed Youtube Videos
 Plugin URI:  https://profiles.wordpress.org/walexconcepts/
 Description: This plugin extends the product details for WooCommerce to embed youtube videos.
 Version:     4.0
 Author:      Awodeyi Adewale Emmanuel
 Author URI:  https://www.walexconcepts.com/
 License:     GPLv2+
 */

function woocommerce_embed_youtube_videos_youtube_call_after_install(){
define('WOOCOMMERCE_EMBED_YOUTUBE_VIDEO_PATH', __FILE__ . '/'); 
$installpath = explode('plugins', WOOCOMMERCE_EMBED_YOUTUBE_VIDEO_PATH);
define('WOOCOMMERCE_EMBED_YOUTUBE_INSTALLATION_PATH', dirname($installpath[0]) . '/'); 
$path = plugin_dir_path( __FILE__ ) . 'system/wc_woocommerce_embed_youtube_videos.sql';
$sql = file_get_contents($path);
require_once( WOOCOMMERCE_EMBED_YOUTUBE_INSTALLATION_PATH . 'wp-admin/includes/upgrade.php' );
dbDelta( $sql );
}
register_activation_hook( __FILE__, 'woocommerce_embed_youtube_videos_youtube_call_after_install' );

function woocommerce_embed_youtube_videos_youtube_call_after_uninstall() {
global $wpdb;
$wpdb->query( 'DROP TABLE IF EXISTS wc_woocommerce_embed_youtube_videos' );
}
register_uninstall_hook( __FILE__, 'woocommerce_embed_youtube_videos_youtube_call_after_uninstall' );


function woocommerce_embed_youtube_videos_youtube_form($post_id) {
 global $wpdb;
 global $post_id;
 $product = wc_get_product($post_id);
 $itemID = $product->id; 
 $result = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM wc_woocommerce_embed_youtube_videos where fk_i_item_id = %d", $itemID ) );		
 foreach ( $result as $row ) {
 $value = $row->s_youtube;	
 }
 
  $args = array(
    'label' => __( 'Enter the youtube url', 'cfwc' ), 
    'placeholder' => '', 
    'class' => 'cfwc-custom-field',
    'style' => '',
    'wrapper_class' => '',
    'value' => __($value, 'ctwc'), 
    'id' => 's_youtube', 
    'name' => 's_youtube', 
    'desc_tip' => true,
    'data_type' => '',
    'custom_attributes' => '', 
    'description' => __( 'e.g http://www.youtube.com/watch?v=ojqWclLQOxk', 'ctwc' ),
  );
  woocommerce_wp_text_input( $args );
}
add_action( 'woocommerce_product_options_general_product_data', 'woocommerce_embed_youtube_videos_youtube_form' );


function woocommerce_embed_youtube_videos_youtube_form_post($post_id) {		
		global $wpdb;
		global $post;
		global $post_id;
		$product = wc_get_product($post_id);
		$itemID = $product->id;
		$itemNAME = $product->name;
		$youtube_video = isset( $_POST[ 's_youtube' ] ) ? sanitize_text_field( $_POST[ 's_youtube' ] ) : '';
        $youtube_id      = woocommerce_embed_youtube_videos_youtube_get_code_from_url($youtube_video);
        if (empty($youtube_video))
            return false;
		if ($post->post_status == 'draft' && $post->post_type == 'product') {
		$wpdb->query( $wpdb->prepare( "INSERT INTO wc_woocommerce_embed_youtube_videos (fk_i_item_id, s_name, s_youtube, s_id) VALUES ( %d, %s, %s, %s)", $itemID, $itemNAME, $youtube_video, $youtube_id ) );
		}else{
		$query = $wpdb->prepare( 'SELECT fk_i_item_id FROM wc_woocommerce_embed_youtube_videos WHERE fk_i_item_id = %d', $itemID );
		$var = $wpdb->get_var( $query );
		if ($var){
		$wpdb->query($wpdb->prepare( "UPDATE wc_woocommerce_embed_youtube_videos SET  
						fk_i_item_id = %d,
						s_name = %s,
						s_youtube = %s,
						s_id= %s where fk_i_item_id = %d", $itemID, $itemNAME, $youtube_video, $youtube_id, $itemID ));
			}			
		}
		
}
function woocommerce_embed_youtube_videos_youtube_get_code_from_url($url) {
    $id = $values = null;
    if (preg_match('/youtube\.com\/watch\?v=([^\&\?\/]+)/', $url, $id)) {
        $values = $id[1];
    } else if (preg_match('/youtube\.com\/embed\/([^\&\?\/]+)/', $url, $id)) {
        $values = $id[1];
    } else if (preg_match('/youtube\.com\/v\/([^\&\?\/]+)/', $url, $id)) {
        $values = $id[1];
    } else if (preg_match('/youtu\.be\/([^\&\?\/]+)/', $url, $id)) {
        $values = $id[1];
    } else if (preg_match('/youtube\.com\/verify_age\?next_url=\/watch%3Fv%3D([^\&\?\/]+)/', $url, $id)) {
        $values = $id[1];
    } else {
        // not an youtube video
    }
    return $values;
}
add_action('save_post_product','woocommerce_embed_youtube_videos_youtube_form_post');			




function woocommerce_embed_youtube_videos_youtube_item_detail() {
		global $wpdb;
		$itemID = get_the_ID();
		$query = $wpdb->prepare( 'SELECT fk_i_item_id FROM wc_woocommerce_embed_youtube_videos WHERE fk_i_item_id = %d', $itemID );
		$detail = $wpdb->get_var( $query );		
		//require_once( dirname( __FILE__ ) . '/item_detail.php' );
		require plugin_dir_path( __FILE__ ) . 'item_detail.php';

}
add_shortcode('youtube_item_detail','woocommerce_embed_youtube_videos_youtube_item_detail');





function woocommerce_embed_youtube_videos_new_custom_product_tab( $tabs ) {
$tabs['video_tab'] = array(
'title' => __( 'Video', 'woocommerce' ), //change "Custom Product tab" to any text you want
'priority' => -1,
'callback' => 'woocommerce_embed_youtube_videos_custom_product_tab_content'
);
return $tabs;
}
function woocommerce_embed_youtube_videos_custom_product_tab_content() {
global $wpdb;
$itemID = get_the_ID();
$query = $wpdb->prepare( 'SELECT fk_i_item_id FROM wc_woocommerce_embed_youtube_videos WHERE fk_i_item_id = %d', $itemID );
$detail = $wpdb->get_var( $query );
//require_once( dirname( __FILE__ ) . '/item_tab.php' );
require plugin_dir_path( __FILE__ ) . 'item_tab.php';

}
add_filter( 'woocommerce_product_tabs', 'woocommerce_embed_youtube_videos_new_custom_product_tab' );



function woocommerce_embed_youtube_videos_youtube_delete_item( $post_id ) {
    global $wpdb;
    global $post_id;
	$product = wc_get_product($post_id);
	$itemID = $product->id; 
    $query = $wpdb->prepare( 'SELECT fk_i_item_id FROM wc_woocommerce_embed_youtube_videos WHERE fk_i_item_id = %d', $itemID );
    $var = $wpdb->get_var( $query );
    if ( $var ) {
        $query2 = $wpdb->prepare( 'DELETE FROM wc_woocommerce_embed_youtube_videos WHERE fk_i_item_id = %d', $itemID );
        $wpdb->query( $query2 );
    }
}
add_action( 'delete_post', 'woocommerce_embed_youtube_videos_youtube_delete_item', 10 );


function woocommerce_embed_youtube_videos_admin_menu() {
    add_menu_page( 'Woocommerce Embed Youtube Videos', 'Woocommerce Embed Youtube Videos', null, 'administrator_woocommerce_embed_youtube_videos', '', plugin_dir_url( __FILE__ ) . 'adminicon.png');
    add_submenu_page( 'administrator_woocommerce_embed_youtube_videos', 'Video Manager', 'Video Manager', 'manage_options', 'videos_manager_woocommerce_embed_youtube_videos', 'woocommerce_embed_youtube_videos_manager' );
	add_submenu_page( 'administrator_woocommerce_embed_youtube_videos', __( 'Help', 'administrator_woocommerce_embed_youtube_videos' ), __( 'Help', 'administrator_woocommerce_embed_youtube_videos' ), 'manage_options', 'help_woocommerce_embed_youtube_videos', 'woocommerce_embed_youtube_videos_help');
	wp_enqueue_style( 'woocommerce_embed_youtube_videos', plugins_url( 'admin/css/woocommerce_embed_youtube_videos.css', __FILE__ ));

}
function woocommerce_embed_youtube_videos_manager(){
	global $wpdb;
	require plugin_dir_path( __FILE__ ) . 'system/msg.inc.php';
	require plugin_dir_path( __FILE__ ) . 'admin/woocommerce_embed_youtube_videos_form.php';
}
function woocommerce_embed_youtube_videos_help(){
	require plugin_dir_path( __FILE__ ) . 'admin/woocommerce_embed_youtube_videos_help.php';
}
add_action('admin_menu', 'woocommerce_embed_youtube_videos_admin_menu');



function woocommerce_embed_youtube_videos_settings_link( $links){
	$links[] = '<a href="admin.php?page=help_woocommerce_embed_youtube_videos">Help</a>' ;		
	$links[] = '<a target="_blank" href="https://walexconcepts.com/index.php?page=item&id=19">Go Premium!</a>' ;
	return $links;
}
add_filter( 'plugin_action_links_'.plugin_basename(__FILE__), 'woocommerce_embed_youtube_videos_settings_link');
