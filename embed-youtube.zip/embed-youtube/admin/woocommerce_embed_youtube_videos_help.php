<?php
	
?>
<div style="float:none" class="well center-block col-md-6">
<h3>Help - User Guide</h3>

== <b>Description</b> ==
<p>
Thank you for installing Woocommerce Embed Youtube Videos. This plugin extends the product details to embed youtube videos. It is absolutely free and always will be.
Visit [demo](https://walexconcepts.com/wordpress/product/mummy-changing-bag/).
</p>


Free Version features:
<p>
<ul>
<li>* Just for only new product. You can use it to embed any video on Woocommerce product details</li>
<li>* Click product details 'Video tab' at frontend to display video content inline.</li>
<li>* Or where applicable to any product details, use shortcode as alternative to "Video tab" at frontend.</li>
<li>* Click 'Video Manager' under 'Woocommerce Embed Youtube Videos' menu at admin page to delete your videos where applicable.</li>
<li>* Insert / edit embedded media like YouTube videos,..</li>
<li>* Theme modifications NOT required.</li>
</ul>
</p>

Premium Features:
<p>
<ul>
<li>* All of the above free version features. </li>
<li>* For already published product or new product. You can use it to embed any video on Woocommerce product details</li>
<li>* Click 'Settings' under 'Woocommerce Embed Youtube Videos' menu at admin page to adjust video height and width.</li>
<li>* Click 'Settings' under 'Woocommerce Embed Youtube Videos' menu at admin page to select your option for either manual or automatic play video.</li>
<li>* Click 'Settings' under 'Woocommerce Embed Youtube Videos' menu at admin page to select your option to mute video.</li>
<li>* Click 'Settings' under 'Woocommerce Embed Youtube Videos' menu at admin page to reorder Video tab to be last at frontend.</li>
<li>* Get alternate 2 diferent table color for video manager at admin page.</li>
<li>* Coding skills NOT required.</li>
</ul>
</p>
</div>