<?php
$current_url = admin_url( "admin.php?page=".$_REQUEST["page"] ); 
if(isset($_REQUEST['a']) && trim($_REQUEST['a'])==3)
{
	
	if(isset($_REQUEST['intid']) && trim($_REQUEST['intid']!=""))
	{	
	$itemID = sanitize_text_field($_REQUEST['intid']); 
    $query = $wpdb->prepare( 'SELECT fk_i_item_id FROM wc_woocommerce_embed_youtube_videos WHERE fk_i_item_id = %d', $itemID );
    $var = $wpdb->get_var( $query );
    if ( $var ) {
        $query2 = $wpdb->prepare( 'DELETE FROM wc_woocommerce_embed_youtube_videos WHERE fk_i_item_id = %d', $itemID );
        $wpdb->query( $query2 );
    }
		
		
		header("location:$current_url&msg=del");
		die();
	}
}				
?>
<style>
    table, td {
		width:50%;
        border: 1px solid black;
        border-collapse: collapse;
        padding: 25px;
     }
</style>
<br><br>
<table align="center">         
<tbody>
            
            <tr>
			<td colspan="5">
				<h3><span style="color:red"><?php if(isset($_REQUEST['msg'])){ echo esc_html($mess[$_REQUEST['msg']]); } ?></h3>
                <h3>Embed Youtube Video Manager</h3>
            </td>
			</tr>
            <tr>
                <td align="center" width=""><strong>fk_i_item_id</strong></td>
                <td align="center" width=""><strong>s_name</strong></td>
                <td align="center" width=""><strong>s_youtube</strong></td>
                <td align="center" width=""><strong>s_id</strong></td>
                <td align="center" width=""><strong>Delete</strong></td>
            </tr>
            <?php
$query = $wpdb->get_results($wpdb->prepare("SELECT COUNT(*) as num FROM wc_woocommerce_embed_youtube_videos"));
foreach($query as $row)	{
$total_pages = $row->num;
}
$targetpage = $current_url;
$limit = 12;
$page = (isset($_GET['paged'])) ? (int)sanitize_text_field($_GET['paged']) : 0;
if($page) 
$start = ($page - 1) * $limit; 			
else
$start = 0;

$p_count = "";
$n_count = "";
$y_count = "";
$s_count = "";
$result = $wpdb->get_results($wpdb->prepare("SELECT * FROM wc_woocommerce_embed_youtube_videos LIMIT $start, %d", $limit ));


if($result)	{
$color="1";
foreach($result as $row)	{			
	$p_count = sanitize_text_field($row->fk_i_item_id);
	$n_count = sanitize_text_field($row->s_name);
    $y_count = sanitize_text_field($row->s_youtube);
	$s_count = sanitize_text_field($row->s_id);
	if($color==1){
?>
            <tr bgcolor='#FFC600'>
                <td align="center" width=""><?php echo esc_html($p_count); ?></td>
                <td align="center" width=""><?php echo esc_html($n_count); ?></td>
                <td align="center" width=""><?php echo esc_html($y_count); ?></td>
                <td align="center" width=""><?php echo esc_html($s_count); ?>'</td>
                <td align="center" width="">
                    <a Title="Click here to Delete" class="link"
                        href="<?php echo esc_html($current_url); ?>&a=3&amp;intid=<?php echo esc_html($p_count);?>"
                        onClick="return confirm('Are you sure to delete this record ?');">
                        <img src="<?php echo esc_url(plugin_dir_url( __FILE__ ) . 'images/delete.bmp'); ?>"
                            border="0" />
                    </a>
                </td>
            </tr>
			<?php $color="2";} else { ?>
			<tr bgcolor='#C6FF00' align="center">
			<td align="center" width=""><?php echo esc_html($p_count); ?></td>
                <td align="center" width=""><?php echo esc_html($n_count); ?></td>
                <td align="center" width=""><?php echo esc_html($y_count); ?></td>
                <td align="center" width=""><?php echo esc_html($s_count); ?>'</td>
                <td align="center" width="">
                    <a Title="Click here to Delete" class="link"
                        href="<?php echo esc_html($current_url); ?>&a=3&amp;intid=<?php echo esc_html($p_count);?>"
                        onClick="return confirm('Are you sure to delete this record ?');">
                        <img src="<?php echo esc_url(plugin_dir_url( __FILE__ ) . 'images/delete.bmp'); ?>"
                            border="0" />
                    </a>
                </td>
			</tr>
             <?php $color="1";}  ?>
            <?php
	}
}
	     
?>
        <tr>
			<td colspan="5">
			<div class="pagination">
        <div class="results">
            <?php
$adjacents = 1;
		if ($page == 0) $page = 1;					
		$prev = $page - 1;							
		$next = $page + 1;							
		$lastpage = ceil($total_pages/$limit);		
		$lpm1 = $lastpage - 1;						
		$pagination = "";
		if($lastpage > 1)
		{	
			$pagination .= "<div class=\"pagination\">";
			if ($page > 1) 
				$pagination.= "<a href=\"$targetpage&paged=$prev\">&laquo; previous</a>";
			else
				$pagination.= "<span class=\"disabled\">&laquo; previous</span>";	
				
			if ($lastpage < 7 + ($adjacents * 2))	
			{	
				for ($counter = 1; $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
				}
			}
			elseif($lastpage > 5 + ($adjacents * 2))	
			{
				
				if($page < 1 + ($adjacents * 2))		
				{
					for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
					}
					$pagination .= "<span class=\"elipses\">...</span>";
					$pagination.= "<a href=\"$targetpage&paged=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage&paged=$lastpage\">$lastpage</a>";		
				}
				
				elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
				{
					$pagination.= "<a href=\"$targetpage&paged=1\">1</a>";
					$pagination.= "<a href=\"$targetpage&paged=2\">2</a>";
					$pagination .= "<span class=\"elipses\">...</span>";
					for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
					}
					$pagination .= "<span class=\"elipses\">...</span>";
					$pagination.= "<a href=\"$targetpage&paged=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage&paged=$lastpage\">$lastpage</a>";		
				}
				
				else
				{
					$pagination.= "<a href=\"$targetpage&paged=1\">1</a>";
					$pagination.= "<a href=\"$targetpage&paged=2\">2</a>";
					$pagination .= "<span class=\"elipses\">...</span>";
					for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage&paged=$counter\">$counter</a>";					
					}
				}
			}
			
			if ($page < $counter - 1) 
				$pagination.= "<a href=\"$targetpage&paged=$next\">next &raquo;</a>";
			else
				$pagination.= "<span class=\"disabled\">next &raquo;</span>";
			$pagination.= "</div>\n";		
		}
	?>

            <?php 
	print $pagination;	
?>
        </div>
    </div>
            </td>
			</tr>
           
		</tbody>
    </table>

    
