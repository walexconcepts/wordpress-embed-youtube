===Embed Youtube Videos===
Contributors: Awodeyi Adewale Emmanuel
Donate link: https://izzumes.com/ 
Tags: embed, video, iframe, youtube, play, woocommerce, flash
Requires at least: 5.4
Tested up to: 6.1.1
Stable tag: 4.0
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin extends the product details for WooCommerce to embed youtube videos. It is absolutely free and always will be.

== Description ==
<p>
This plugin extends the product details to embed youtube videos. It is absolutely free and always will be.
Visit [demo](https://walexconcepts.com/wordpress/product/mummy-changing-bag/).
</p>

Free Version features:
<p>
<ul>
<li>* Just for only new product. You can use it to embed any video on Woocommerce product details</li>
<li>* Click product details 'Video tab' at frontend to display video content inline.</li>
<li>* Or where applicable to any product details, use shortcode as alternative to "Video tab" at frontend.</li>
<li>* Click 'Video Manager' under 'Woocommerce Embed Youtube Videos' menu at admin page to delete your videos where applicable.</li>
<li>* Insert / edit embedded media like YouTube videos,..</li>
<li>* Theme modifications NOT required.</li>
</ul>
</p>

Premium Features:
<p>
<ul>
<li>* All of the above free version features. </li>
<li>* For already published product or new product. You can use it to embed any video on Woocommerce product details</li>
<li>* Click 'Settings' under 'Woocommerce Embed Youtube Videos' menu at admin page to adjust video height and width.</li>
<li>* Click 'Settings' under 'Woocommerce Embed Youtube Videos' menu at admin page to select your option for either manual or automatic play video.</li>
<li>* Click 'Settings' under 'Woocommerce Embed Youtube Videos' menu at admin page to select your option to mute video.</li>
<li>* Click 'Settings' under 'Woocommerce Embed Youtube Videos' menu at admin page to reorder Video tab to be last at frontend.</li>
<li>* Coding skills NOT required.</li>
</ul>
</p>

== Installation ==
<p>
<ul>
<li>1. Upload files of woo_embed_youtube_videos to the `/wp-content/plugins/`</li> 
<li>2. Activate the plugin through the 'Plugins' menu in WordPress</li>
<li>3. Click product details 'Video tab' at frontend to display video content inline.</li>
<li>4. Or where applicable to any product details, use shortcode as alternative to "Video tab" at frontend.</li>
<li>5. At backend , click 'Video Manager' under 'Woocommerce Embed Youtube Videos' menu in WordPress to delete Videos.</li>
<li>6. At backend , click 'Help' under 'Woocommerce Embed Youtube Videos' menu in WordPress for help user guide.</li>
</ul>
</p>

== Frequently Asked Questions ==

= Does Woocommerce Embed Youtube Videos work with any Wordpress theme? =
Yes, it does. You can use it with any Wordpress theme.

= Do I get free support for this free plugin? = 
Yes, we can provide support via email and chat if needed.

== Screenshots ==
<p>
<ul>
<li>1. screenshot-1 Enter youtube url to add product</li>
<li>2. screenshot-2 Enter youtube url to edit or update product</li>
<li>3. screenshot-3 Delete unwanted videos </li>
<li>4. screenshot-4 Result display on product details</li>
<li>5. screenshot-5 Video settings configuration</li> 
</ul>
</p>

== Changelog ==
<p>
<ul>
= 1.0 =
<li>* roll out April, 07, 2022)</li>
</ul>
</p>
